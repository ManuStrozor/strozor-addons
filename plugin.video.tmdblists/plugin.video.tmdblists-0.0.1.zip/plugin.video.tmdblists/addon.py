import xbmcgui

xbmcgui.Window().doModal()